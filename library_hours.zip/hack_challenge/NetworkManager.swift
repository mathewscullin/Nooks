//
//  NetworkManager.swift
//  hack_challenge
//
//  Created by Mathew Scullin on 11/29/18.
//  Copyright © 2018 Mathew Scullin. All rights reserved.
//

import Foundation
import Alamofire

class NetworkManager {
    
}
